﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");


namespace SzimulacioTKAMBS
{
    abstract class Entity
    {
        public int eletero { get; set; }
        public abstract void korcsokkenes();
    }

    class Program
    {
        static void Main(string[] args)
        {
            //menu itemek
            string[] MenuElemek = { "Start", "Beállítások", "Kilépés" };
            string[] NehezsegiSzintek = { "Normál", "Nehéz" };

            int Menuindex = 0;
            int DifficultyIndex = 0;
            //ablak mérete
            Console.SetWindowSize(100, 35);
            Console.Title = "Fejlesztői Konzol";

            // menu loop
            bool startgomb = false;
            while (startgomb == false)
            {
                // Clear the console
                Console.Clear();

                // középre igazít
                int centerY = Console.WindowHeight / 3;
                int xtengely = Console.WindowWidth / 3;
                int SzelessegMenu = 35;
                int MagassagMenu = MenuElemek.Length;

                int menuX = xtengely - (SzelessegMenu / 3);
                int menuY = centerY - (MagassagMenu / 3);

                for (int i = 0; i < MenuElemek.Length; i++)
                {
                    Console.SetCursorPosition(menuX, menuY + i);

                    if (i == Menuindex)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Blue;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.BackgroundColor = ConsoleColor.Black;
                    }

                    Console.Write(MenuElemek[i]);
                }

                Console.ResetColor();

                ConsoleKeyInfo keyInfo = Console.ReadKey(true);

                switch (keyInfo.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (Menuindex <= 0)
                        {
                            Menuindex = MenuElemek.Length - 1;
                        }
                        else
                        {
                            Menuindex = Menuindex - 1;
                        }
                        break;

                    case ConsoleKey.DownArrow:

                        if (Menuindex == MenuElemek.Length - 1)
                        {
                            Menuindex = 0;
                        }
                        else { Menuindex++; }
                        break;
                    case ConsoleKey.Enter:
                        // Menu pontok

                        switch (Menuindex)
                        {
                            case 0:
                                Console.Clear();
                                Console.ReadLine();
                                // játék ide
                                startgomb = true;
                                break;
                            case 1:
                                // Beállítások menu
                                //Középre igazítás
                                xtengely = Console.WindowWidth / 2;
                                centerY = Console.WindowHeight / 2;
                                SzelessegMenu = 20;
                                MagassagMenu = MenuElemek.Length;

                                menuX = xtengely - (SzelessegMenu / 2);
                                menuY = centerY - (MagassagMenu / 2);

                                bool exitSettings = false;
                                while (!exitSettings)
                                {
                                    Console.Clear();
                                    for (int i = 0; i < NehezsegiSzintek.Length; i++)
                                    {
                                        if (i == DifficultyIndex)
                                        {
                                            Console.ForegroundColor = ConsoleColor.White;
                                            Console.BackgroundColor = ConsoleColor.Blue;
                                        }
                                        else
                                        {
                                            Console.ForegroundColor = ConsoleColor.Gray;
                                            Console.BackgroundColor = ConsoleColor.Black;
                                        }

                                        Console.WriteLine(NehezsegiSzintek[i]);
                                    }

                                    keyInfo = Console.ReadKey(true);
                                    switch (keyInfo.Key)
                                    {
                                        case ConsoleKey.UpArrow:
                                            if (DifficultyIndex <= 0)
                                            {
                                                DifficultyIndex = NehezsegiSzintek.Length - 1;
                                            }
                                            else
                                            {
                                                DifficultyIndex--;
                                            }
                                            break;

                                        case ConsoleKey.DownArrow:
                                            if (DifficultyIndex >= NehezsegiSzintek.Length - 1)
                                            {
                                                DifficultyIndex = 0;
                                            }
                                            else
                                            {
                                                DifficultyIndex++;
                                            }
                                            break;

                                        case ConsoleKey.Enter:
                                            string difficultySetting;
                                            switch (DifficultyIndex)
                                            {
                                                case 0:
                                                    difficultySetting = "10 10,10,2";
                                                    break;

                                                case 1:
                                                    difficultySetting = "15 15,6,6";
                                                    break;
                                            }

                                            System.IO.File.WriteAllText(@"C:\temp\difficulty.txt", difficultySetting);
                                            exitSettings = true;
                                            break;

                                        case ConsoleKey.Escape:
                                            exitSettings = true;
                                            break;

                                    }

                                    Console.ResetColor();
                                }
                                break;

                            case 2:
                                Environment.Exit(0);
                                return;

                        }
                        break;

                }

            }
            // Olvassa be a difficulty.txt fájlt
            string difficultyData = System.IO.File.ReadAllText(@"C:\Temp\difficulty.txt");
            string[] parameterek = difficultyData.Split(',');

            // Mátrix mérete
            string[] MatrixMeret = parameterek[0].Split(' ');
            int Sorok = int.Parse(MatrixMeret[0]);
            int Oszlopok = int.Parse(MatrixMeret[1]);


            // Játékterület kiíratása
            static void JatekMezoKiiratasa(Entity[,] JatekMezo)
            {
                for (int i = 0; i < JatekMezo.GetLength(0); i++)
                {
                    for (int j = 0; j < JatekMezo.GetLength(1); j++)
                    {
                        Entity entity = JatekMezo[i, j];
                        if (entity is Nyul)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.Write("N ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else if (entity is Roka)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.Write("R ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        /*
                        else if (entity is Fu)
                        {
                            Console.Write("F ");
                        }
                        */
                        else
                        {
                            Console.Write(". ");
                        }
                    }
                    Console.WriteLine();
                }
            }

            // Játéktér inicializálása
            Entity[,] JatekMezo = new Entity[Sorok, Oszlopok];

            // Nyulak és rókák száma
            int NyulMennyiseg = int.Parse(parameterek[1]);
            int RokaMennyisegRoka = int.Parse(parameterek[2]);

            Random veletlen = new Random();
            for (int i = 0; i < NyulMennyiseg; i++)
            {
                int x, y;
                do
                {
                    x = veletlen.Next(Sorok);
                    y = veletlen.Next(Oszlopok);
                } while (JatekMezo[x, y] != null);
                JatekMezo[x, y] = new Nyul(4);
            }

            for (int i = 0; i < RokaMennyisegRoka; i++)
            {
                int x, y;
                do
                {
                    x = veletlen.Next(Sorok);
                    y = veletlen.Next(Oszlopok);
                } while (JatekMezo[x, y] != null);
                JatekMezo[x, y] = new Roka(8);
            }

            //Körök száma
            Console.WriteLine("Kérem adja meg a körszámot:");
            int BealitottKorok = int.Parse(Console.ReadLine());

            // Szimulációs lépések végrehajtása
            for (int Korok = 1; Korok <= BealitottKorok; Korok++)
            {
                Console.Clear(); // Képernyő törlése minden lépés előtt
                Console.WriteLine($"Kör: {Korok}");

                int NyulSzamlalas = 0;
                int RokaSzamlalas = 0;

                for (int i = 0; i < Sorok; i++)
                {
                    for (int j = 0; j < Oszlopok; j++)
                    {
                        Entity entity = JatekMezo[i, j];

                        if (entity != null)
                        {
                            if (entity is Nyul nyul)
                            {
                                NyulLepes(JatekMezo, nyul, i, j);
                                NyulSzamlalas++;
                            }
                            else if (entity is Roka roka)
                            {
                                RokaLepes(JatekMezo, roka, i, j);
                                RokaSzamlalas++;
                            }
                        }
                    }
                }

                JatekMezoKiiratasa(JatekMezo);
                Thread.Sleep(1000);

                // Ellenőrzés, hogy maradt-e nyúl vagy róka a pályán
                if (NyulSzamlalas == 0)
                {
                    Console.WriteLine("A rókák nyertek, mert nincs több nyúl a pályán.");
                    break; // kilép a ciklusból
                }
                else if (RokaSzamlalas == 1)
                {
                    Console.WriteLine("A nyulak nyertek, mert nincs több róka a pályán.");
                    break; // kilép a ciklusból
                }
                else if (BealitottKorok <= Korok)
                {
                    Console.WriteLine("Vége lett a szimulációnak, így a nyulak nyertek");
                    break; // kilép a ciklusból
                }
            }

            Console.ReadLine();
            Console.ReadKey();
        }

        // Üres cella keresése
        static void UresMezoKeres(Entity[,] JatekMezo, int x, int y, out int newX, out int newY)
        {
            int maximumProbalkozas = 10;
            Random veletlen = new Random();
            newX = x;
            newY = y;

            for (int i = 0; i < maximumProbalkozas; i++)
            {
                int Irany = veletlen.Next(4); // 0: fel, 1: le, 2: balra, 3: jobbra

                switch (Irany)
                {
                    case 0:
                        if (x > 0) newX = x - 1;
                        break;
                    case 1:
                        if (x < JatekMezo.GetLength(0) - 1) newX = x + 1;
                        break;
                    case 2:
                        if (y > 0) newY = y - 1;
                        break;
                    case 3:
                        if (y < JatekMezo.GetLength(1) - 1) newY = y + 1;
                        break;
                }

                if (JatekMezo[newX, newY] == null)
                {
                    return;
                }
            }

        }

        // Entitás mozgatása
        static void MozgasMetodus(Entity[,] JatekMezo, Entity entity, int x, int y)
        {
            int newX, newY;
            UresMezoKeres(JatekMezo, x, y, out newX, out newY);
            JatekMezo[x, y] = null;
            JatekMezo[newX, newY] = entity;
        }

        // Nyúl szaporodása
        static void NyulSzaporod(Entity[,] JatekMezo, Nyul nyul, int x, int y)
        {
            int UresXMezo, UresYMezo;
            UresMezoKeres(JatekMezo, x, y, out UresXMezo, out UresYMezo);

            if (JatekMezo[UresXMezo, UresYMezo] == null && nyul.eletero >= 5)
            {
                Nyul newNyul = new Nyul(2);
                JatekMezo[UresXMezo, UresYMezo] = newNyul;
                Console.WriteLine("Egy új nyúl született.");  // Logolás
                Thread.Sleep(3000);
                nyul.korcsokkenes(); // Az új nyúl születésekor a szülő nyúl jóllakottsága csökken
            }
        }

        // Nyul szimulációs lépés
        static void NyulLepes(Entity[,] JatekMezo, Nyul nyul, int x, int y)
        {
            // Nyul mozgása
            MozgasMetodus(JatekMezo, nyul, x, y);

            // Nyul táplálkozása
            if (nyul.eletero > 0)
            {
                if (JatekMezo[x, y] is Fu fu)
                {
                    Nyul.zsengeeves(nyul);
                    Fu.eltunes(fu);
                }
            }

            // Nyul jóllakottságának csökkentése
            nyul.korcsokkenes();

            // Nyul szaporodása
            NyulSzaporod(JatekMezo, nyul, x, y);
        }

        /// Róka szimulációs lépés
        static void RokaLepes(Entity[,] JatekMezo, Roka roka, int x, int y)
        {
            // Róka mozgása
            MozgasMetodus(JatekMezo, roka, x, y);

            // Róka táplálkozása
            if (roka.eletero > 0)
            {
                if (ProbaNyulEves(JatekMezo, x, y))
                {
                    Console.WriteLine("A róka megette a nyulat.");  // Logolás
                    Roka.nyuleves(roka);
                }

                // Róka jóllakottságának csökkenése
                Roka.korcsokkenes(roka);

                // Róka szaporodása
                RokaSzaporod(JatekMezo, roka, x, y);
            }

            // Róka szaporodása
            static void RokaSzaporod(Entity[,] JatekMezo, Roka roka, int x, int y)
            {
                int UresXMezo, UresYMezo;
                UresMezoKeres(JatekMezo, x, y, out UresXMezo, out UresYMezo);

                if (JatekMezo[UresXMezo, UresYMezo] == null && roka.eletero >= 8)
                {
                    Roka ujRoka = new Roka(5);
                    JatekMezo[UresXMezo, UresYMezo] = ujRoka;
                    Console.WriteLine("Egy új róka született.");  // Logolás
                    roka.korcsokkenes(); // Az új róka születésekor a szülő róka jóllakottsága csökken
                }
            }

            // Róka eszik nyulat
            static bool ProbaNyulEves(Entity[,] JatekMezo, int x, int y)
            {
                int Sorok = JatekMezo.GetLength(0);
                int Oszlopok = JatekMezo.GetLength(1);

                for (int i = Math.Max(0, x - 2); i <= Math.Min(x + 2, Sorok - 1); i++)
                {
                    for (int j = Math.Max(0, y - 2); j <= Math.Min(y + 2, Oszlopok - 1); j++)
                    {
                        if (JatekMezo[i, j] is Nyul)
                        {
                            JatekMezo[i, j] = null;
                            return true;
                        }
                    }
                }

                return false;
            }
        }
    }
}